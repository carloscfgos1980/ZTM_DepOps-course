#!/bin/bash

# defining a function: method 1
function print_something () {  .
        echo "I'm a simple function!"
}
 
# defining a function: method 2
display_something () {
        echo "Hello functions!"
}
# either of the above methods of specifying a function is valid. 

# calling the functions 
print_something
display_something
