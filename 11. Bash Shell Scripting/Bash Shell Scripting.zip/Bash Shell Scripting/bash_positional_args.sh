#!/bin/bash
echo "\$0 is $0"
echo "\$1 is $1"
echo "\$2 is $2"
echo "\$3 is $3"
echo "\$* is $*"
echo "\$# is $#"

# Move to the script's directory and run it as: ./script_name.sh Ubuntu CentOS "Kali Linux" "Windows 10"